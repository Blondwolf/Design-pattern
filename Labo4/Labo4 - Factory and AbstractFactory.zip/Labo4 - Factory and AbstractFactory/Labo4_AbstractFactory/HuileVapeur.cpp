#include "HuileVapeur.h"

using namespace std;

HuileVapeur::HuileVapeur()
{
    //ctor
}

HuileVapeur::~HuileVapeur()
{
    //dtor
}

void HuileVapeur::print()
{
    cout << "- Huile pour vapeur"<<endl;
}
