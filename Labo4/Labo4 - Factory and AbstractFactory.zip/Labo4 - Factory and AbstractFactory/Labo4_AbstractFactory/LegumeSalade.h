#ifndef LEGUMESALADE_H
#define LEGUMESALADE_H
#include "Legume.h"

class LegumeSalade: public Legume
{
public:
    LegumeSalade();
    virtual ~LegumeSalade();

    void print();
protected:
private:
};

#endif // LEGUMESALADE_H
