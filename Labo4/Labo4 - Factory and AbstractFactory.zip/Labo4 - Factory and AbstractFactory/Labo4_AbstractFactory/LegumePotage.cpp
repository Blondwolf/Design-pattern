#include "LegumePotage.h"

using namespace std;

LegumePotage::LegumePotage()
{
    //ctor
}

LegumePotage::~LegumePotage()
{
    //dtor
}

void LegumePotage::print()
{
    cout << "- Legume pour potage"<<endl;
}
