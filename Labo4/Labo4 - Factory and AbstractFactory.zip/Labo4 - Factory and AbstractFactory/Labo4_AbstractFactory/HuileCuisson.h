#ifndef HUILECUISSON_H
#define HUILECUISSON_H
#include "Huile.h"

class HuileCuisson: public Huile
{
public:
    HuileCuisson();
    virtual ~HuileCuisson();

    void print();
protected:
private:
};

#endif // HUILECUISSON_H
