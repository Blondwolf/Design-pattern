#ifndef LEGUMEVAPEUR_H
#define LEGUMEVAPEUR_H
#include "Legume.h"

class LegumeVapeur: public Legume
{
public:
    LegumeVapeur();
    virtual ~LegumeVapeur();

    void print();
protected:
private:
};

#endif // LEGUMEVAPEUR_H
