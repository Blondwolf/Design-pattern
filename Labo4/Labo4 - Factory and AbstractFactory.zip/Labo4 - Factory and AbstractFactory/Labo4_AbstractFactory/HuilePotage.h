#ifndef HUILEPOTAGE_H
#define HUILEPOTAGE_H
#include "Huile.h"

class HuilePotage: public Huile
{
public:
    HuilePotage();
    virtual ~HuilePotage();

    void print();
protected:
private:
};

#endif // HUILEPOTAGE_H
