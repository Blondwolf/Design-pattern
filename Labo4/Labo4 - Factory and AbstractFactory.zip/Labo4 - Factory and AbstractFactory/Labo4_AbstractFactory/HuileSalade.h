#ifndef HUILESALADE_H
#define HUILESALADE_H
#include "Huile.h"

class HuileSalade: public Huile
{
public:
    HuileSalade();
    virtual ~HuileSalade();

    void print();
protected:
private:
};

#endif // HUILESALADE_H
