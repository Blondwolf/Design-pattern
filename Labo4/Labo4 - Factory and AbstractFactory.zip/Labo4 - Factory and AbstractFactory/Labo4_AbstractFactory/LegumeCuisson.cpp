#include "LegumeCuisson.h"

using namespace std;

LegumeCuisson::LegumeCuisson()
{
    //ctor
}

LegumeCuisson::~LegumeCuisson()
{
    //dtor
}

void LegumeCuisson::print()
{
    cout << "- Legume pour cuisson"<<endl;
}
