#ifndef LEGUMEPOTAGE_H
#define LEGUMEPOTAGE_H
#include "Legume.h"

class LegumePotage: public Legume
{
public:
    LegumePotage();
    virtual ~LegumePotage();

    void print();
protected:
private:
};

#endif // LEGUMEPOTAGE_H
