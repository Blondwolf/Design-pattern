#include "HuileCuisson.h"

using namespace std;

HuileCuisson::HuileCuisson()
{
    //ctor
}

HuileCuisson::~HuileCuisson()
{
    //dtor
}

void HuileCuisson::print()
{
    cout << "- Huile pour cuisson"<<endl;
}
