#include "HuilePotage.h"

using namespace std;

HuilePotage::HuilePotage()
{
    //ctor
}

HuilePotage::~HuilePotage()
{
    //dtor
}

void HuilePotage::print()
{
    cout << "- Huile pour potage"<<endl;
}
