#include "HuileSalade.h"

using namespace std;

HuileSalade::HuileSalade()
{
    //ctor
}

HuileSalade::~HuileSalade()
{
    //dtor
}

void HuileSalade::print()
{
    cout << "- Huile pour salade"<<endl;
}
