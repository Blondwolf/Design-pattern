#include "LegumeSalade.h"

using namespace std;

LegumeSalade::LegumeSalade()
{
    //ctor
}

LegumeSalade::~LegumeSalade()
{
    //dtor
}

void LegumeSalade::print()
{
    cout << "- Legume pour salade"<<endl;
}
