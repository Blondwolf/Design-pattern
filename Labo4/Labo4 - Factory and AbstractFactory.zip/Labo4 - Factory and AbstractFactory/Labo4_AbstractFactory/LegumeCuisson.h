#ifndef LEGUMECUISSON_H
#define LEGUMECUISSON_H
#include "Legume.h"

class LegumeCuisson: public Legume
{
public:
    LegumeCuisson();
    virtual ~LegumeCuisson();

    void print();
protected:
private:
};

#endif // LEGUMECUISSON_H
