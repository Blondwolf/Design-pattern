#include "LegumeVapeur.h"

using namespace std;

LegumeVapeur::LegumeVapeur()
{
    //ctor
}

LegumeVapeur::~LegumeVapeur()
{
    //dtor
}

void LegumeVapeur::print()
{
    cout << "- Legume pour vapeur"<<endl;
}
