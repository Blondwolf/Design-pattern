#include "Legume.h"

Legume::Legume()
{
    //ctor
}

Legume::~Legume()
{
    //dtor
}
